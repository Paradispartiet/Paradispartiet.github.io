# Kunst quiz completion patch

Inneholder ferdige set-baserte kunstquizzer:

- `data/quiz/kunst/munch_museet_sets.json`
  - 6 sett
  - 42 spørsmål
  - `categoryId: kunst`
  - `targetId: munch_museet`
  - `emne_id` med `em_kunst_*`

- `data/quiz/kunst/vigelandsparken_sets.json`
  - 6 sett
  - 42 spørsmål
  - `categoryId: kunst`
  - `targetId: vigelandsparken`
  - `emne_id` med `em_kunst_*`

Manifest:
- Bruk oppføringene i `manifest_kunst_entries.json`
- Fjern den gamle kompakte `munch_museet`-oppføringen før du legger inn de 6 eksplisitte MUNCH-settene.
- For `vigelandsparken`: unngå å ha både `data/quiz/by/vigelandsparken_sets.json` og `data/quiz/kunst/vigelandsparken_sets.json` aktivt på samme `targetId`, fordi quizmotoren indekserer etter `targetId`.
